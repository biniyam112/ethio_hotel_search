import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hotels/bloc/auth_bloc.dart';
import 'package:hotels/data_provider/auth_provider.dart';
import 'package:hotels/models/auth.dart';
import 'package:hotels/repository/auth_repository.dart';
import 'package:hotels/screens/sign_in/sign_in_page.dart';
import 'package:http/http.dart' as http;

// import 'HomePage.dart';

void main() async {
  try{await GetStorage.init();}catch(err) {print(err);}
  runApp(MyApp());
}

//the get storage way
class MyApp extends StatelessWidget {
  AuthRepository authRepository = AuthRepository(
      dataProvider: AuthDataProvider(
    httpClient: http.Client(),
  ));
  AuthData a = AuthData(email: "hotel@gmail.com", password: 'password');

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => AuthBloc(repository: authRepository),
      child: MaterialApp(
        theme: ThemeData(
          primaryColor: Colors.purple,
        ),
        debugShowCheckedModeBanner: false,
        home: SignInPage(),
      ),
    );
  }
}
